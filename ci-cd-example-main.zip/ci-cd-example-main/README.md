# ci-cd-example
A simple .NET 6 Web API with a CI/CD pipeline using GitHub Actions.
